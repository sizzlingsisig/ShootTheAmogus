#ifndef COLLISION_H
#define COLLISION_H

#include "gametypes.h"

void checkBulletEnemyCollisions(void);
void checkPlayerEnemyCollisions(void);

#endif // COLLISION_H
