#ifndef SOUND_H
#define SOUND_H

#include "gametypes.h"

void playSound(SoundType type);

#endif // SOUND_H
